import ui.TodoApp;

public class Main {
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> {
            new TodoApp().setVisible(true);
        });
    }
}
