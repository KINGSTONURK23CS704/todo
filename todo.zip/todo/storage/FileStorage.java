package storage;

import java.io.*;
import java.util.*;
import models.Todo;

public class FileStorage {
    private static final String FILE_NAME = "todo.txt";

    public static List<Todo> loadTodos() {
        List<Todo> todos = new ArrayList<>();
        File file = new File(FILE_NAME);

        try {
            if (!file.exists()) {
                file.createNewFile();
            }

            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length == 3) {
                    int id = Integer.parseInt(parts[0]);
                    String title = parts[1];
                    boolean completed = Boolean.parseBoolean(parts[2]);
                    todos.add(new Todo(id, title, completed));
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return todos;
    }

    public static void saveTodos(List<Todo> todos) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))) {
            for (Todo todo : todos) {
                writer.write(todo.getId() + "|" + todo.getTitle() + "|" + todo.isCompleted());
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
