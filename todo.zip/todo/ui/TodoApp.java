package ui;

import models.Todo;
import storage.FileStorage;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.List;            // ✅ EXPLICITLY import this
import java.util.ArrayList;       // ✅ If you're using new ArrayList<>()

public class TodoApp extends JFrame {
    private DefaultTableModel tableModel;
    private JTable table;
    private JTextField taskField;
    private JButton addButton, deleteButton, refreshButton;

    private List<Todo> todoList;

    public TodoApp() {
        setTitle("Todo List (File Version)");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        tableModel = new DefaultTableModel(new String[]{"ID", "Task", "Completed"}, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        JPanel inputPanel = new JPanel();
        taskField = new JTextField(20);
        addButton = new JButton("Add Task");
        deleteButton = new JButton("Delete Task");
        refreshButton = new JButton("Refresh");

        inputPanel.add(taskField);
        inputPanel.add(addButton);
        inputPanel.add(deleteButton);
        inputPanel.add(refreshButton);

        add(scrollPane, BorderLayout.CENTER);
        add(inputPanel, BorderLayout.SOUTH);

        loadTodos();

        addButton.addActionListener(e -> addTodo());
        deleteButton.addActionListener(e -> deleteTodo());
        refreshButton.addActionListener(e -> loadTodos());
    }

    private void loadTodos() {
        todoList = FileStorage.loadTodos();
        tableModel.setRowCount(0);

        for (Todo todo : todoList) {
            tableModel.addRow(new Object[]{todo.getId(), todo.getTitle(), todo.isCompleted()});
        }
    }

    private void addTodo() {
        String title = taskField.getText().trim();
        if (title.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a task.");
            return;
        }

        int nextId = todoList.isEmpty() ? 1 : todoList.get(todoList.size() - 1).getId() + 1;
        Todo newTodo = new Todo(nextId, title, false);
        todoList.add(newTodo);
        FileStorage.saveTodos(todoList);
        taskField.setText("");
        loadTodos();
    }

    private void deleteTodo() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a task to delete.");
            return;
        }

        int id = (int) tableModel.getValueAt(selectedRow, 0);
        todoList.removeIf(todo -> todo.getId() == id);
        FileStorage.saveTodos(todoList);
        loadTodos();
    }
}
